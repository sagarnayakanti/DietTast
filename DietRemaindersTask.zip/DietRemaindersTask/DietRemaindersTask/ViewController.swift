//
//  ViewController.swift
//  DietRemaindersTask
//
//  Created by Hema Phani on 10/22/18.
//  Copyright © 2018 Hema Phani. All rights reserved.
//

import UIKit
import UserNotifications
class ViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
    
    var weekArray=["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]
    @IBOutlet weak var dayCV: UICollectionView!
    var urlSessionObj:URLSession!
    var urlReq:URLRequest!
    var mondayFoodArray=[String]()
    var mondayTimeArray=[Int]()
    var thursdayTimeArray=[Int]()
    var thursdayFoodArray=[String]()
    var wedFoodArray=[String]()
    var wedTimeArray=[Int]()
    override func viewDidLoad() {
        super.viewDidLoad()
        createUI()
        
        let present=Date()
        let indian=Calendar(identifier: .indian)
        var cmp=indian.dateComponents([.day, .weekday, .hour, .minute], from: present)
        cmp.weekday=2
       
        
       
        // Do any additional setup after loading the view, typically from a nib.
    }
    func notifications(title:String,subtitle:String,badge:Int,hours:Int,minutes:Int,identifier:String,weekDay:Int){
       
        let content=UNMutableNotificationContent()
        content.title=title
        content.subtitle=subtitle
        content.badge=1

        
        let now=Date()
        let indianCalender=Calendar(identifier: .indian)
        var components = indianCalender.dateComponents([.year, .month, .day, .hour, .minute, .second, .weekdayOrdinal], from: now)
        components.hour=hours-1
        components.minute=minutes
        components.second=0
        components.weekday=weekDay
        
        let date=indianCalender.date(from: components)
        let triggerDaily=Calendar.current.dateComponents([.hour, .minute, .second,], from: date!)
        var trigger=UNCalendarNotificationTrigger(dateMatching: triggerDaily, repeats: true)
        var request=UNNotificationRequest(identifier: identifier, content: content, trigger: trigger)
        UNUserNotificationCenter.current().add(request) { (error) in
        }
    }
    func createUI(){
        var layout=UICollectionViewFlowLayout()
        layout.itemSize=CGSize(width: (UIScreen.main.bounds.width-50)/2, height: (UIScreen.main.bounds.width-50)/2)
        layout.minimumLineSpacing=10
        layout.minimumInteritemSpacing=10
        dayCV.collectionViewLayout=layout
        dayCV.delegate=self
        dayCV.dataSource=self
        
        
        //json data
        var thread1=DispatchQueue(label: "t1", qos: .userInteractive)
        thread1.async {
            self.urlSessionObj=URLSession.shared
            self.urlReq=URLRequest(url: URL(string: "https://naviadoctors.com/dummy/")!)
            self.urlReq.httpMethod="POST"
            self.urlSessionObj.dataTask(with: self.urlReq) { (data, res, err) in
                guard let data=data else{
                    return
                }
                do{
                var serverData=try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! [String:Any]
                    guard let weekDietData=serverData["week_diet_data"] as? [String:Any] else{
                        return
                    }
                    guard let mondayArray=weekDietData["monday"] as? [[String:Any]] else{
                        return
                    }
                    for i in 0..<mondayArray.count{
                        
                        self.mondayFoodArray.append(mondayArray[i]["food"] as! String)
                        self.mondayTimeArray.append((mondayArray[i]["meal_time"]! as! NSString).integerValue)
                    }
                    //notification
                    for i in 0..<self.mondayFoodArray.count{
                        self.notifications(title: "Diet Alert!", subtitle: self.mondayFoodArray[i], badge: i, hours: self.mondayTimeArray[i], minutes: 55, identifier: self.mondayFoodArray[i], weekDay: 3)
                    }
                    guard let thursdayArray=weekDietData["thursday"] as? [[String:Any]] else{
                        return
                    }
                    for i in 0..<thursdayArray.count{
                        self.thursdayFoodArray.append(thursdayArray[i]["food"] as! String)
                        self.thursdayTimeArray.append((thursdayArray[i]["meal_time"]! as! NSString).integerValue)
                     
                    }
                   //notification
                    for i in 0..<self.thursdayFoodArray.count{
                        self.notifications(title: "Diet Alert!", subtitle: self.thursdayFoodArray[i], badge: i, hours: self.thursdayTimeArray[i], minutes: 55, identifier: self.thursdayFoodArray[i], weekDay: 5)
                    }
                    guard let wednesdayArray=weekDietData["wednesday"] as? [[String:Any]] else{
                        return
                    }
                    for i in 0..<wednesdayArray.count{
                        self.wedFoodArray.append(wednesdayArray[i]["food"] as! String)
                        self.wedTimeArray.append((wednesdayArray[i]["meal_time"]! as! NSString).integerValue)
                        
                    }
                   //notification
                    for i in 0..<self.wedFoodArray.count{
                        self.notifications(title: "Diet Alert!", subtitle: self.wedFoodArray[i], badge: i, hours: self.wedTimeArray[i], minutes: 55, identifier: self.wedFoodArray[i], weekDay: 4)
                    }
                }catch{
                    print("error in parsing")
                }
                }.resume()
        }
        
        
        
       
        
        
        
        
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return weekArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        var cell=collectionView.dequeueReusableCell(withReuseIdentifier: "diet", for: indexPath) as! DayCollectionViewCell
        cell.dayLbl.text=weekArray[indexPath.row]
        cell.cellImage.alpha=0.85
        cell.layer.cornerRadius=15
        cell.layer.masksToBounds=true
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        var resultsVC=self.storyboard?.instantiateViewController(withIdentifier: "ResultsViewController") as! ResultsViewController
        if(indexPath.row==0){
            resultsVC.day=weekArray[indexPath.row]
            resultsVC.foodArray=mondayFoodArray
            resultsVC.timeArray=mondayTimeArray
            self.navigationController?.pushViewController(resultsVC, animated: true)
        }else if(indexPath.row==1){
            resultsVC.day=weekArray[indexPath.row]
            self.navigationController?.pushViewController(resultsVC, animated: true)
        }else if(indexPath.row==2){
            resultsVC.day=weekArray[indexPath.row]
            resultsVC.foodArray=wedFoodArray
            resultsVC.timeArray=wedTimeArray
            self.navigationController?.pushViewController(resultsVC, animated: true)
        }else if(indexPath.row==3){
            resultsVC.foodArray=thursdayFoodArray
            resultsVC.timeArray=thursdayTimeArray
            resultsVC.day=weekArray[indexPath.row]
            self.navigationController?.pushViewController(resultsVC, animated: true)
        }else if(indexPath.row==4){
            resultsVC.day=weekArray[indexPath.row]
            self.navigationController?.pushViewController(resultsVC, animated: true)
        }else if(indexPath.row==5){
            resultsVC.day=weekArray[indexPath.row]
            self.navigationController?.pushViewController(resultsVC, animated: true)
        }
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


