//
//  ResultsViewController.swift
//  DietRemaindersTask
//
//  Created by Hema Phani on 10/22/18.
//  Copyright © 2018 Hema Phani. All rights reserved.
//

import UIKit

class ResultsViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    @IBOutlet weak var dayLbl: UILabel!
    var day:String=""
    @IBOutlet weak var resultsTV: UITableView!
    var foodArray=[String]()
    var timeArray=[Int]()
    var noContentImage:UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        resultsTV.delegate=self
        resultsTV.dataSource=self
        dayLbl.text=day
        resultsTV.reloadData()
        noContentImage=UIImageView(frame: CGRect(x: 20, y: Int(resultsTV.frame.origin.y), width: Int(resultsTV.bounds.width), height: 300))
        noContentImage.image=#imageLiteral(resourceName: "nodiet")
        noContentImage.contentMode = .scaleAspectFit
        view.addSubview(noContentImage)
        noContentImage.isHidden=true
        if(foodArray.isEmpty==true){
            resultsTV.isHidden=true
            noContentImage.isHidden=false
        }else{
            noContentImage.isHidden=true
            resultsTV.isHidden=false
        }
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return foodArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell=tableView.dequeueReusableCell(withIdentifier: "time", for: indexPath) as! TimeTableCell
        cell.food.text=foodArray[indexPath.row]
        cell.timeLbl.text=String(timeArray[indexPath.row])
        return cell
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
