//
//  DayCollectionViewCell.swift
//  DietRemaindersTask
//
//  Created by Hema Phani on 10/22/18.
//  Copyright © 2018 Hema Phani. All rights reserved.
//

import UIKit

class DayCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var dayLbl: UILabel!
  
    
    @IBOutlet weak var cellImage: UIImageView!
    
    
}
